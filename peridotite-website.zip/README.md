# Peridotite Website

Website sederhana bertema Peridotit (batuan mantel bumi).

## Fitur
- Halaman informatif tentang peridotit
- Desain sederhana dengan tema warna hijau batuan
- Siap di-commit ke GitHub

## Cara Menjalankan
Cukup buka file `index.html` di browser.
